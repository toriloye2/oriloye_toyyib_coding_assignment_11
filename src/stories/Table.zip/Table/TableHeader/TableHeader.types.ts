
export type TableHeaderProps= {
  className?: string;
  children?: React.ReactNode;
}