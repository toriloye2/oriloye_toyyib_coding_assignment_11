export type TableCellProps ={
  className?: string;
  children?: React.ReactNode;
}