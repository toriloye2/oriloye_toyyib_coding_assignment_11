export type TableFooterProps= {
  className?: string;
  children?: React.ReactNode;
}