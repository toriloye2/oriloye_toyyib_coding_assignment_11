export type TableProps = {
  className?: string;
  children?: React.ReactNode;
  backgroundColor?: string;
  disabled?: boolean;
}






