export type TableRowProps = {
  className?: string;
  children?: React.ReactNode;
}